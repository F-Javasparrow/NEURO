name = "Neurotrauma 0.1.3";
dir = "@neuro";
author = "Kal'tsitly"

tooltipOwned = "Neurotrauma";
description = "Neurotrauma";
picture = "mod.paa";
logoSmall = "mod.paa";
logo = "mod.paa";
logoOver = "mod.paa";
hidePicture = 0;
hideName = 0;
